import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import Home from './pages/Home';
import Search from './pages/Search';
import LiveStream from './pages/LiveStream';
import VideoDetail from './pages/VideoDetail';
import Profile from './pages/Profile';
import Navigation from './components/Navigation';
import VideoUpload from './pages/VideoUpload';
import VideoPlayer from './components/Video/VideoPlayer';
import './App.css'; // Import the CSS file
import { useAuth } from './context';
import SignIn from './components/Auth/SignIn';
import Signup from './components/Auth/Signup';
import Otp from './components/Auth/Otp';

function App() {
  const { isAuth } = useAuth();
  console.log(isAuth, localStorage.getItem('token'))
  return (
    <Router>
      <div className="App">
        <Navigation />
        <div className="">
          <Routes>
            {
              isAuth? (
                <>
                  <Route path="/" element={<Home />} />
                  <Route path="/search" element={<Search />} />
                  <Route path="/live" element={<LiveStream />} />
                  <Route path="/video/:id" element={<VideoDetail />} />
                  <Route path="/profile" element={<Profile />} />
                  <Route path="/upload" element={<VideoUpload />} />
                  <Route path="/videoplayer" element={<VideoPlayer />} />
                  <Route path="*" element={<Navigate to="/" />} />
                </>
              ) : (
                <>
                  <Route path="/signin" element={ <SignIn /> } />
                  <Route path="/signup" element={ <Signup /> } />
                  <Route path="/verify" element={ <Otp /> } />
                  <Route path="*" element={<Navigate to="/signin" />} />

                </>
              )
            }
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;
